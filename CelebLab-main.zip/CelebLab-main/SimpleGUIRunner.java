import javax.swing.JFrame;

public class SimpleGUIRunner
{
	public static void main(String[] args)
	{
		JFrame sample = new JFrame();
		sample.setVisible(true);
	}

}
