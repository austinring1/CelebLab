public class Celebrity {
    
}
